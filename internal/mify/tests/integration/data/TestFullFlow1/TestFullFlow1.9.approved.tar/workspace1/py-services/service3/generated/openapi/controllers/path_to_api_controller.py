from typing import List, Dict
from aiohttp import web

from service3.generated.openapi import util

from service3.handlers.path.to.api.service import path_to_api_get as _service

async def path_to_api_get(request: web.Request, ) -> web.Response:
    """sample handler

    


    """

    ctx_builder = request.app['request_context_builder']
    ctx = ctx_builder.build(request)

    resp = await _service(ctx, )
    return util.make_response("application/json", resp, 200)