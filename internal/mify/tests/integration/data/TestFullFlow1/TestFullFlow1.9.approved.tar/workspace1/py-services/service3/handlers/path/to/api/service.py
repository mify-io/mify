from service3.generated.core.request_context import MifyRequestContext



async def path_to_api_get(ctx: MifyRequestContext, ):
    """sample handler

    


    """
    return {}
