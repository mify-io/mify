class ServiceExtra:
    def __init__(self, service_context):
        # Here you can do your custom service initialization, prepare dependencies
        pass
