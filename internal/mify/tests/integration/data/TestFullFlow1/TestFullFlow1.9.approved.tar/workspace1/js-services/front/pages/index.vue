<template>
  <Sample/>
</template>

<script>
// uncomment if you have clients
/* import Clients from '@/generated/core/clients' */

export default {
  name: 'Index',
  async fetch() {
    // let client = new Clients.Service1.Api()
  }
}
</script>
