// vim: set ft=go:

package app

import (
	"net/http"

	"example.com/namespace/workspace1/go-services/internal/api-gateway/generated/core"
)

type ServiceExtra struct {
	// Append your dependencies here
}

func NewServiceExtra(ctx *core.MifyServiceContext) (*ServiceExtra, error) {
	// Here you can do your custom service initialization, prepare dependencies
	extra := &ServiceExtra{
		// Here you can initialize your dependencies
	}
	return extra, nil
}
