# vim: set ft=python:
class RequestExtra:
    def __init__(self):
        # Append your dependencies here
        pass
