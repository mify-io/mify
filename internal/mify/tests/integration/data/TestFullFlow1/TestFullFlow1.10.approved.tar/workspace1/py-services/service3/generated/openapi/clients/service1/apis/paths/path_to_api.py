from service3.generated.openapi.clients.service1.paths.path_to_api.get import ApiForget


class PathToApi(
    ApiForget,
):
    pass