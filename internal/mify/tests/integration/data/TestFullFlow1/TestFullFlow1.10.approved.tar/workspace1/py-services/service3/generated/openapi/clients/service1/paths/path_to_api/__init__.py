# do not import all endpoints into this module because that uses a lot of memory and stack frames
# if you need the ability to import all endpoints from this module, import them with
# from service3.generated.openapi.clients.service1.paths.path_to_api import Api

from service3.generated.openapi.clients.service1.paths import PathValues

path = PathValues.PATH_TO_API