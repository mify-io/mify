import typing_extensions

from service3.generated.openapi.clients.service1.apis.tags import TagValues
from service3.generated.openapi.clients.service1.apis.tags.api_ import Api_

TagToApi = typing_extensions.TypedDict(
    'TagToApi',
    {
        TagValues.API: Api_,
    }
)

tag_to_api = TagToApi(
    {
        TagValues.API: Api_,
    }
)