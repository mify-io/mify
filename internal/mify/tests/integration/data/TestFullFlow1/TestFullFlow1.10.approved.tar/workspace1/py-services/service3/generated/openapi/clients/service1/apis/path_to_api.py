import typing_extensions

from service3.generated.openapi.clients.service1.paths import PathValues
from service3.generated.openapi.clients.service1.apis.paths.path_to_api import PathToApi

PathToApi = typing_extensions.TypedDict(
    'PathToApi',
    {
        PathValues.PATH_TO_API: PathToApi,
    }
)

path_to_api = PathToApi(
    {
        PathValues.PATH_TO_API: PathToApi,
    }
)