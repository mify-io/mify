# vim: set ft=python:
from mify_generated.services.service3.app.mify_app import MifyServiceApp


def main():
    app = MifyServiceApp()
    app.run()

if __name__ == '__main__':
    main()
