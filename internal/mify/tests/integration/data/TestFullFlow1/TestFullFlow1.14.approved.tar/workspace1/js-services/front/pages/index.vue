<template>
  <div>
  <Sample/>
  </div>
</template>

<script>

export default {
  name: 'Index',
  async fetch() {
    // Example backend call
    // let service1Backend = this.$clients.service1();
    // try {
    //     var resp = await service1Backend.pathToApiGet();
    // } catch (e) {
    //     console.log(e);
    // }
  }
}
</script>
